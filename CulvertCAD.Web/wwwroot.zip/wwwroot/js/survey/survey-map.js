﻿
(() => {
    "use strict";

    const canvas = document.getElementById("survey-map-canvas");
    const status = document.getElementById("survey-map-status");

    if (!canvas || !status) return;

    if (!window.THREE) {
        status.textContent =
            "Map unavailable: Three.js could not be loaded.";
        return;
    }

    try {
        const readJson = (id) => {
            const element = document.getElementById(id);
            return element ? JSON.parse(element.textContent || "null") : null;
        };

        const surveyPoints = readJson("survey-map-points-data") || [];
        const alignmentPoints = readJson("survey-map-alignment-data") || [];
        const culverts = readJson("survey-map-culverts-data") || [];

        if (!surveyPoints.length && !alignmentPoints.length) {
            status.textContent = "No survey or alignment points are available.";
            return;
        }

        const THREE = window.THREE;

        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0x101820);

        const camera = new THREE.PerspectiveCamera(
            50,
            1,
            0.1,
            1000000
        );

        const renderer = new THREE.WebGLRenderer({
            canvas,
            antialias: true
        });

        renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));

        scene.add(new THREE.AmbientLight(0xffffff, 1.4));

        const light = new THREE.DirectionalLight(0xffffff, 1.2);
        light.position.set(100, 200, 150);
        scene.add(light);

        const validSurvey = surveyPoints.filter(p =>
            Number.isFinite(Number(p.Easting)) &&
            Number.isFinite(Number(p.Northing)) &&
            Number.isFinite(Number(p.RL))
        );

        const validAlignment = alignmentPoints.filter(p =>
            Number.isFinite(Number(p.Easting)) &&
            Number.isFinite(Number(p.Northing))
        );

        const allPoints = [
            ...validSurvey.map(p => ({
                x: Number(p.Easting),
                y: Number(p.RL),
                z: Number(p.Northing)
            })),
            ...validAlignment.map(p => ({
                x: Number(p.Easting),
                y: Number(p.ExistingRL ?? 0),
                z: Number(p.Northing)
            }))
        ];

        const minE = Math.min(...allPoints.map(p => p.x));
        const maxE = Math.max(...allPoints.map(p => p.x));
        const minN = Math.min(...allPoints.map(p => p.z));
        const maxN = Math.max(...allPoints.map(p => p.z));
        const minRL = Math.min(...allPoints.map(p => p.y));
        const maxRL = Math.max(...allPoints.map(p => p.y));

        // Local origin keeps large UTM coordinates numerically manageable.
        const centerE = (minE + maxE) / 2;
        const centerN = (minN + maxN) / 2;
        const baseRL = minRL;

        const terrainScale = 1;
        const verticalExaggeration = 3;

        const toWorld = (easting, northing, rl) => new THREE.Vector3(
            (Number(easting) - centerE) * terrainScale,
            (Number(rl) - baseRL) * verticalExaggeration,
            (Number(northing) - centerN) * terrainScale
        );

        // Survey points: observed survey locations and elevations.
        const surveyGeometry = new THREE.BufferGeometry();
        const surveyPositions = [];

        validSurvey.forEach(p => {
            const v = toWorld(p.Easting, p.Northing, p.RL);
            surveyPositions.push(v.x, v.y, v.z);
        });

        surveyGeometry.setAttribute(
            "position",
            new THREE.Float32BufferAttribute(surveyPositions, 3)
        );

        const surveyMaterial = new THREE.PointsMaterial({
            color: 0x58a6ff,
            size: 2.5,
            sizeAttenuation: true
        });

        scene.add(new THREE.Points(surveyGeometry, surveyMaterial));

        // Imported road alignment: its RL may be absent.
        if (validAlignment.length > 1) {
            const alignmentGeometry = new THREE.BufferGeometry();
            const positions = [];

            validAlignment.forEach(p => {
                const rl = Number.isFinite(Number(p.ExistingRL))
                    ? Number(p.ExistingRL)
                    : baseRL;

                const v = toWorld(p.Easting, p.Northing, rl);
                positions.push(v.x, v.y, v.z);
            });

            alignmentGeometry.setAttribute(
                "position",
                new THREE.Float32BufferAttribute(positions, 3)
            );

            const alignmentLine = new THREE.Line(
                alignmentGeometry,
                new THREE.LineBasicMaterial({ color: 0xf0883e })
            );

            scene.add(alignmentLine);
        }

        // Detected culvert groups: shown at the mean location of their points.
        const culvertPoints = [];

        culverts.forEach(c => {
            const members = c.Points || c.points || [];

            if (members.length) {
                const easting = members.reduce(
                    (sum, p) => sum + Number(p.Easting ?? p.easting ?? 0), 0
                ) / members.length;

                const northing = members.reduce(
                    (sum, p) => sum + Number(p.Northing ?? p.northing ?? 0), 0
                ) / members.length;

                const known = validSurvey.filter(p =>
                    members.some(m =>
                        Number(m.PointNo ?? m.pointNo) === Number(p.PointNo)
                    )
                );

                const rl = known.length
                    ? known.reduce((sum, p) => sum + Number(p.RL), 0) / known.length
                    : baseRL;

                culvertPoints.push(toWorld(easting, northing, rl));
            }
        });

        if (culvertPoints.length) {
            const geometry = new THREE.BufferGeometry();
            const positions = [];

            culvertPoints.forEach(v => positions.push(v.x, v.y, v.z));

            geometry.setAttribute(
                "position",
                new THREE.Float32BufferAttribute(positions, 3)
            );

            scene.add(new THREE.Points(
                geometry,
                new THREE.PointsMaterial({
                    color: 0x3fb950,
                    size: 6,
                    sizeAttenuation: true
                })
            ));
        }

        const span = Math.max(maxE - minE, maxN - minN, 10);
        const target = new THREE.Vector3(
            0,
            ((maxRL - minRL) * verticalExaggeration) / 2,
            0
        );

        const initialDistance = span * 1.2;

        const setCameraView = (view) => {
            const width = canvas.clientWidth || 800;
            const height = canvas.clientHeight || 600;
            const aspect = width / height;

            camera.aspect = aspect;
            camera.updateProjectionMatrix();

            const verticalSpan = Math.max(
                (maxRL - minRL) * verticalExaggeration,
                10
            );

            const horizontalSpan = Math.max(
                maxE - minE,
                maxN - minN,
                10
            );

            const verticalFov = THREE.MathUtils.degToRad(camera.fov);
            const horizontalFov = 2 * Math.atan(
                Math.tan(verticalFov / 2) * aspect
            );

            const distanceForWidth =
                (horizontalSpan / 2) / Math.tan(horizontalFov / 2);

            const distanceForHeight =
                (verticalSpan / 2) / Math.tan(verticalFov / 2);

            const distance = Math.max(
                distanceForWidth,
                distanceForHeight
            ) * 1.25;

            if (view === "top" || view === "north") {
                camera.position.set(
                    target.x,
                    target.y + distance,
                    target.z
                );
                camera.up.set(0, 0, -1);
            } else {
                camera.up.set(0, 1, 0);
                camera.position.set(
                    target.x + distance * 0.65,
                    target.y + distance * 0.65,
                    target.z + distance * 0.65
                );
            }

            camera.lookAt(target);

            if (controls) {
                controls.target.copy(target);
                controls.update();
            }
        };

        camera.position.set(
            target.x + initialDistance * 0.65,
            target.y + initialDistance * 0.65,
            target.z + initialDistance * 0.65
        );
        camera.lookAt(target);

        let controls = null;

        if (THREE.OrbitControls) {
            controls = new THREE.MapControls(camera, renderer.domElement);
            controls.target.copy(target);
            controls.enableDamping = true;

            // Enable rotation, zoom and panning.
            controls.enableRotate = true;
            controls.enableZoom = true;
            controls.enablePan = true;

            // Right mouse button pans the map.
            controls.mouseButtons.LEFT = THREE.MOUSE.PAN;
            controls.mouseButtons.MIDDLE = THREE.MOUSE.DOLLY;
            controls.mouseButtons.RIGHT = THREE.MOUSE.ROTATE;

            controls.update();
        }

        const resize = () => {
            const width = canvas.clientWidth;
            const height = canvas.clientHeight;

            if (!width || !height) return;

            renderer.setSize(width, height, false);
            camera.aspect = width / height;
            camera.updateProjectionMatrix();
        };

        // Survey map navigation buttons
        document.getElementById("survey-map-recenter")?.addEventListener("click", () => {
            setCameraView("3d");
        });

        document.getElementById("survey-map-top-view")?.addEventListener("click", () => {
            setCameraView("top");
        });

        document.getElementById("survey-map-3d-view")?.addEventListener("click", () => {
            setCameraView("3d");
        });

        document.getElementById("survey-map-north-up")?.addEventListener("click", () => {
            setCameraView("north");
        });

        window.addEventListener("resize", resize);
        resize();

        const animate = () => {
            requestAnimationFrame(animate);

            if (controls) controls.update();

            renderer.render(scene, camera);
        };

        animate();

        status.textContent =
            `Survey points: ${ validSurvey.length } | ` +
            `Alignment points: ${ validAlignment.length } | ` +
            `Detected culvert groups: ${ culverts.length }. ` +
            `Blue = survey points; orange = road alignment; green = culvert groups. ` +
            `Vertical scale is exaggerated for visibility.`;

    } catch (error) {
        console.error("Survey map error:", error);
        status.textContent =
            "The survey map could not be rendered. Check the browser console for details.";
    }
})();
